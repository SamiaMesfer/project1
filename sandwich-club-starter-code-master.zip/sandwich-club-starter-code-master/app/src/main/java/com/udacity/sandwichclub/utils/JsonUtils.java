package com.udacity.sandwichclub.utils;

import android.util.Log;

import com.udacity.sandwichclub.model.Sandwich;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class JsonUtils {

    public static Sandwich parseSandwichJson(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            JSONObject name = obj.getJSONObject("name");
            JSONArray alsoKnownAs = name.getJSONArray("alsoKnownAs");
            JSONArray ingredients = obj.getJSONArray("ingredients");

            List<String> alsoKnownAsList = new ArrayList<String>();
            for(int i = 0; i < alsoKnownAs.length(); i++){
                alsoKnownAsList.add(alsoKnownAs.getString(i));
            }

            List<String> ingredientsList = new ArrayList<String>();
            for(int i = 0; i < ingredients.length(); i++){
                ingredientsList.add(ingredients.getString(i));
            }

            return new Sandwich(name.getString("mainName"),alsoKnownAsList, obj.getString("placeOfOrigin"), obj.getString("description"), obj.getString("image"),ingredientsList );
        } catch (Throwable t) {
            Log.e("Sandwich-club app", "Could not parse JSON");
            return null;
        }

    }
}
